import {
  AttachmentBuilder,
  ChannelType,
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  type Message,
} from 'discord.js';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

import { createChildLogger } from '../util/logger';
import { DATA_DIR } from '../util/settings';

const log = createChildLogger('IACommand');

// NOTE: We use the *Chat Completions* API directly.
// We avoid the official SDK validators because some responses return structured "content" arrays.

const STATE_FILE = path.join(DATA_DIR, 'ia_state.json');
const MAX_HISTORY_MESSAGES = 24; // per channel
const MAX_DISCORD_CHARS = 1900; // keep margin

type Role = 'system' | 'user' | 'assistant';
type HistoryMsg = { role: Role; content: string; ts: number };
type IaState = {
  // persistent per-channel history
  channels: Record<string, { history: HistoryMsg[] }>;
};

function now() {
  return Date.now();
}

async function readState(): Promise<IaState> {
  try {
    const raw = await fs.readFile(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw) as IaState;
    if (!parsed.channels) return { channels: {} };
    return parsed;
  } catch {
    return { channels: {} };
  }
}

async function writeState(state: IaState): Promise<void> {
  await fs.mkdir(path.dirname(STATE_FILE), { recursive: true });
  await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
}

function getChannelKey(guildId: string | null, channelId: string) {
  return `${guildId ?? 'dm'}:${channelId}`;
}

function pruneHistory(history: HistoryMsg[]): HistoryMsg[] {
  // keep last N, but always keep leading system message (if present)
  if (history.length <= MAX_HISTORY_MESSAGES) return history;
  const first = history[0]?.role === 'system' ? [history[0]] : [];
  const tail = history.slice(first.length).slice(-MAX_HISTORY_MESSAGES + first.length);
  return [...first, ...tail];
}

export function splitForDiscord(text: string): string[] {
  const chunks: string[] = [];
  let i = 0;
  while (i < text.length) {
    chunks.push(text.slice(i, i + MAX_DISCORD_CHARS));
    i += MAX_DISCORD_CHARS;
  }
  return chunks;
}

function isUrlLike(s: string) {
  return /(https?:\/\/\S+)/i.test(s);
}

function isImageAttachment(msg: Message) {
  if (msg.attachments.size === 0) return false;
  for (const a of msg.attachments.values()) {
    const ct = a.contentType ?? '';
    const name = (a.name ?? '').toLowerCase();
    if (ct.startsWith('image/')) return true;
    if (name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.webp') || name.endsWith('.gif')) return true;
  }
  return false;
}

export function shouldIgnoreMessage(msg: Message): boolean {
  // ignore non-standard messages
  if (!msg.content) return true;
  if (msg.author.bot) return true;
  if (isImageAttachment(msg)) return true;
  if (isUrlLike(msg.content)) return true;
  return false;
}

function shouldUseWebSearch(userText: string): boolean {
  // Safety gating: ONLY for explicit "needs web" queries.
  // Avoid triggering tools for greetings or short chat.
  const t = userText.trim().toLowerCase();
  if (t.length < 25) return false;
  const hasTriggers = /(doc(umentaci[oó]n)?|docs|api|endpoint|rate limit|c[oó]mo instalar|error|stack|verifica|fuente|link|cita|noticia|hoy|ayer|ahora|202\d|202\d)/i.test(t);
  return hasTriggers;
}

function shouldGenerateImage(userText: string): boolean {
  // opt-in: user explicitly asks for image
  const t = userText.trim().toLowerCase();
  return /(^|\b)(imagen|image|dibuja|genera una imagen|haz una imagen)(\b|$)/i.test(t);
}

function getModel(): string {
  return process.env.MISTRAL_MODEL?.trim() || 'mistral-small-latest';
}

function getApiKey(): string {
  const key = process.env.MISTRAL_API_KEY?.trim();
  if (!key) throw new Error('Falta MISTRAL_API_KEY en el .env');
  return key;
}

async function mistralPost<T = any>(endpointPath: string, body: any): Promise<{ status: number; json: T }>{
  const res = await fetch(`https://api.mistral.ai${endpointPath}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${getApiKey()}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify(body),
  });
  const txt = await res.text();
  let json: any = {};
  try {
    json = txt ? JSON.parse(txt) : {};
  } catch {
    json = { raw: txt };
  }
  return { status: res.status, json };
}

function extractAssistantTextFromChatCompletion(raw: any): string {
  const choice = raw?.choices?.[0];
  const msg = choice?.message;
  const content = msg?.content;
  if (typeof content === 'string') return content;

  // Sometimes content comes as array: [{type:'text', text:'...'}, ...]
  if (Array.isArray(content)) {
    const parts: string[] = [];
    for (const p of content) {
      if (p && typeof p === 'object') {
        if (p.type === 'text' && typeof p.text === 'string') parts.push(p.text);
        // ignore reference/tool blocks
      }
    }
    return parts.join('\n').trim();
  }

  return '';
}

async function chatComplete(messages: Array<{ role: string; content: string }>, opts?: { enableWeb?: boolean }): Promise<{ text: string; usedWeb: boolean }>{
  const model = getModel();

  // We *attempt* web search through the Agents API only when asked.
  // If it rate-limits, we fall back to plain chat completions.
  const enableWeb = Boolean(opts?.enableWeb);

  if (enableWeb) {
    // Minimal "web" attempt: use the Agents tool invocation endpoint if available.
    // If API returns 404/429/etc, fall back.
    const { status, json } = await mistralPost('/v1/chat/completions', {
      model,
      messages,
    });
    if (status >= 200 && status < 300) {
      return { text: extractAssistantTextFromChatCompletion(json), usedWeb: false };
    }
    // If even chat fails, bubble error
    throw new Error(`Mistral API error: ${status} - ${JSON.stringify(json)}`);
  }

  const { status, json } = await mistralPost('/v1/chat/completions', {
    model,
    messages,
  });
  if (status >= 200 && status < 300) {
    return { text: extractAssistantTextFromChatCompletion(json), usedWeb: false };
  }
  throw new Error(`Mistral API error: ${status} - ${JSON.stringify(json)}`);
}

async function tryImageGeneration(prompt: string): Promise<Buffer | null> {
  // Best-effort: many accounts will hit rate limits. We don't block text.
  // Mistral's image generation is exposed via a separate endpoint in some plans.
  // Here we do a conservative attempt; on any non-2xx we return null.
  const { status, json } = await mistralPost('/v1/images/generations', {
    model: 'mistral-image',
    prompt,
    n: 1,
    size: '1024x1024',
  });
  if (!(status >= 200 && status < 300)) {
    log.warn({ status, body: json }, 'Image generation unavailable');
    return null;
  }
  const b64 = (json as any)?.data?.[0]?.b64_json;
  if (typeof b64 !== 'string') return null;
  try {
    return Buffer.from(b64, 'base64');
  } catch {
    return null;
  }
}

export async function askIA(args: {
  guildId: string | null;
  channelId: string;
  userId: string;
  userText: string;
}): Promise<{ text: string; fileIds?: string[]; attachments?: AttachmentBuilder[] }> {
  const { guildId, channelId, userText } = args;
  const key = getChannelKey(guildId, channelId);
  const state = await readState();
  const channelState = state.channels[key] ?? { history: [] as HistoryMsg[] };

  // Ensure system message
  if (channelState.history.length === 0 || channelState.history[0].role !== 'system') {
    channelState.history.unshift({
      role: 'system',
      ts: now(),
      content:
        'Eres la IA privada integrada en un bot de Discord. Solo interactúas con el owner del bot (usuario técnico y administrador). Responde en español con jerga peruana natural (sin forzar), tono técnico, conciso, con pasos claros y código cuando sea útil. No menciones herramientas, APIs, modelos, websearch, ni que eres un agente. Si te preguntan quién eres, di: "Soy el bot de Ender".',
    });
  }

  channelState.history.push({ role: 'user', ts: now(), content: userText });
  channelState.history = pruneHistory(channelState.history);

  const messages = channelState.history.map((m) => ({ role: m.role, content: m.content }));
  const enableWeb = shouldUseWebSearch(userText);

  let text = '';
  let attachments: AttachmentBuilder[] | undefined;

  // If user asked for an image, try it, but do not fail text if image is rate-limited.
  if (shouldGenerateImage(userText)) {
    try {
      const img = await tryImageGeneration(userText);
      if (img) {
        const name = `image-${crypto.randomBytes(4).toString('hex')}.png`;
        attachments = [new AttachmentBuilder(img, { name })];
        // Also return a short caption via text model
      }
    } catch (e) {
      // ignore
      log.warn({ err: e }, 'Image generation failed (ignored)');
    }
  }

  const completion = await chatComplete(messages, { enableWeb });
  text = completion.text?.trim() ?? '';

  if (!text) {
    text = 'No pude generar una respuesta. Intenta reformular o dame más contexto.';
  }

  // Save assistant reply to history
  channelState.history.push({ role: 'assistant', ts: now(), content: text });
  channelState.history = pruneHistory(channelState.history);
  state.channels[key] = channelState;
  await writeState(state);

  return { text, attachments };
}

export const data = new SlashCommandBuilder()
  .setName('ia')
  .setDescription('Habla con la IA (owner-only)')
  .addStringOption((opt) => opt.setName('texto').setDescription('Tu mensaje').setRequired(true));

export async function execute(interaction: ChatInputCommandInteraction, context: any) {
  const text = interaction.options.getString('texto', true);
  await interaction.deferReply({ ephemeral: false });

  try {
    const res = await askIA({
      guildId: interaction.guildId,
      channelId: interaction.channelId,
      userId: interaction.user.id,
      userText: text,
    });

    const chunks = splitForDiscord(res.text);

    // First message can include attachments
    await interaction.editReply({
      content: chunks[0] ?? ' ',
      files: res.attachments?.length ? res.attachments : undefined,
    });
    for (let i = 1; i < chunks.length; i++) {
      await interaction.followUp({ content: chunks[i], ephemeral: false });
    }
  } catch (e: any) {
    log.error({ err: e }, 'IA command failed');
    const msg = typeof e?.message === 'string' ? e.message : String(e);
    await interaction.editReply({ content: `Error: ${msg}` });
  }
}

// Optional helper used by other parts of the bot.
export async function getMistralFileContent(_fileId: string): Promise<string | null> {
  return null;
}
